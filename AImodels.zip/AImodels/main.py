from fastapi import FastAPI , HTTPException
from pydantic import BaseModel
from hiding import hide
from resume import resume
from classificationapi import classification


app = FastAPI()

class TextIn(BaseModel):
    text: str
    types: str

class TextCHIn(BaseModel):
    text: str
    types: list[str]

class RecomOut(BaseModel):
    content: str


@app.get("/")
def home():
    return {"health_check": "OK"}


@app.post("/resume", response_model=RecomOut)
async def allow(payload: TextIn):
    allows = resume(payload.text,payload.types)
    if allows:
        return {"allowing": allows}
    else:
        raise HTTPException(status_code=404, detail="No recommendations generated")
    
@app.post("/classification", response_model=RecomOut)
async def classifier(payload: TextCHIn):
    allows = classification(payload.text,payload.types)
    if allows:
        return {"allowing": allows}
    else:
        raise HTTPException(status_code=404, detail="No recommendations generated")
    
@app.post("/hide", response_model=RecomOut)
async def hidie(payload: TextCHIn):
    allows = hide(payload.text,payload.types)
    if allows:
        return {"allowing": allows}
    else:
        raise HTTPException(status_code=404, detail="No recommendations generated")